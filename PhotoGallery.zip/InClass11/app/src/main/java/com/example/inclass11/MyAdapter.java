package com.example.inclass11;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
    StorageReference storageReference = firebaseStorage.getReference();

        ArrayList<ImageObject> data;

    public MyAdapter(ArrayList<ImageObject> data) {
            this.data = data;
        }

        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view, parent,false);
            MyViewHolder viewHolder = new MyViewHolder(view);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
            ImageObject imageObject = data.get(position);
            Picasso.get().load(imageObject.url).into(holder.image);
           //holder.imageList.add(imageObject);
            holder.genImage = imageObject;
        }

    public void removeAt(int position){
        data.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position,data.size());
    }

        @Override
        public int getItemCount() {
            return data.size();
        }

        public  class MyViewHolder extends RecyclerView.ViewHolder{
            ImageObject genImage;
            ArrayList<ImageObject>  imageList = new ArrayList<>();
            private ImageView image;
            public MyViewHolder(@NonNull View itemView) {
                super(itemView);
                image = itemView.findViewById(R.id.imageView);
                image.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View view) {

                        StorageReference desertRef = storageReference.child(genImage.getImagePath());
                        desertRef.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                            }
                        });
                        removeAt(getPosition());
                        return false;
                    }

                });


            }
        }
    }


