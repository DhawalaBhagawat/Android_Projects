package com.example.inclass11;

public class ImageObject {
    String url;

    @Override
    public String toString() {
        return "ImageObject{" +
                "url='" + url + '\'' +
                ", imagePath='" + imagePath + '\'' +
                '}';
    }

    String imagePath;

    public ImageObject(String url, String imagePath) {
        this.url = url;
        this.imagePath = imagePath;
    }



    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }




}
